class Data:
    
    def __init__(self):
        self.availableARSTransfer = 0
        self.availableUSDTransfer = 0
        self.availableARSATM = 0
        self.availableUSDATM = 0
        self.cuit = '0'
        self.nombre = '-'
        self.cbuUSD = '-'
        self.cbuARS = '-'
        self.partnerId = 0
        
